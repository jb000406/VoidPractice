using UnityEngine;
using System.Collections;

public class BarrierEffect : MonoBehaviour
{
    public Material barrierMaterial; // 결계 Shader를 사용하는 머티리얼
    public float creationTime = 2f; // 생성 효과 시간

    private float dissolveValue = 1f; // Dissolve 파라미터

    void Start()
    {
        // 초기 상태에서 결계가 보이지 않음
        barrierMaterial.SetFloat("_Dissolve", dissolveValue);

        // 생성 효과 시작
        StartCoroutine(CreateBarrier());
    }

    IEnumerator CreateBarrier()
    {
        float elapsed = 0f;

        while (elapsed < creationTime)
        {
            elapsed += Time.deltaTime;
            dissolveValue = Mathf.Lerp(1f, 0f, elapsed / creationTime);
            barrierMaterial.SetFloat("_Dissolve", dissolveValue);

            yield return null;
        }

        // 생성 완료
        barrierMaterial.SetFloat("_Dissolve", 0f);
    }
}
