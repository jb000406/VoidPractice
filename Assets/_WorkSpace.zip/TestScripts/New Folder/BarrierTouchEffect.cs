using UnityEngine;

public class BarrierTouchEffect : MonoBehaviour
{
    public ParticleSystem touchEffect; // 터치 효과 파티클
    public AudioClip touchSound; // 터치 효과 사운드
    private AudioSource audioSource;

    void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // 터치 효과 재생
            Instantiate(touchEffect, other.transform.position, Quaternion.identity);

            // 사운드 재생
            audioSource.PlayOneShot(touchSound);
        }
    }
}
