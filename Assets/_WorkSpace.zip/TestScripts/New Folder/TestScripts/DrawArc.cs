using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class DrawCircleEffect : MonoBehaviour
{
    public float radius = 20f;    // 원의 반지름
    public float yPosition = 3f;  // y축 고정
    public int segments = 100;    // 원의 세그먼트 수 (부드러움)
    public GameObject[] directionObject; // NE, NW, SW, SE 오브젝트
    public GameObject clonePrefab;       // 분신 생성용 프리팹
    public float finalDestinationHeight = 0f;  // 최종 목적지의 높이
    public Shield shield;

    public enum Direction
    {
        NE, NW, SW, SE
    }

    private Dictionary<Direction, List<Vector3>> DirectionPoint = new Dictionary<Direction, List<Vector3>>();
    private Vector3[] circlePoints; // 원의 점 배열
    private Vector3 origin = Vector3.zero; // 원점
    private List<GameObject> clones = new List<GameObject>(); // 생성된 분신 저장 리스트

    public void StartEffect()
    {
        Invoke(nameof(StartDrawEffect), 2f);
    }
    private void StartDrawEffect()
    {
        // 원의 점 미리 계산
        circlePoints = new Vector3[segments + 1];
        for (int i = 0; i <= segments; i++)
        {
            float angle = i * Mathf.PI * 2f / segments;
            circlePoints[i] = new Vector3(
                Mathf.Cos(angle) * radius, // x 좌표
                yPosition,                 // y 좌표 고정
                Mathf.Sin(angle) * radius  // z 좌표
            );
        }

        // 딕셔너리 초기화
        DirectionPoint[Direction.NE] = new List<Vector3>();
        DirectionPoint[Direction.NW] = new List<Vector3>();
        DirectionPoint[Direction.SW] = new List<Vector3>();
        DirectionPoint[Direction.SE] = new List<Vector3>();

        // 대각선 점 저장
        StoreDiagonalPoints();

        // 각 디렉션 오브젝트를 이동
        StartCoroutine(MoveObject(Direction.NE, directionObject[0]));
        StartCoroutine(MoveObject(Direction.NW, directionObject[1]));
        StartCoroutine(MoveObject(Direction.SW, directionObject[2]));
        StartCoroutine(MoveObject(Direction.SE, directionObject[3]));
    }

    void StoreDiagonalPoints()
    {
        // 기준점 정의
        Vector3 east = new Vector3(radius, yPosition, 0);    // 동
        Vector3 west = new Vector3(-radius, yPosition, 0);   // 서
        Vector3 north = new Vector3(0, yPosition, radius);   // 북
        Vector3 south = new Vector3(0, yPosition, -radius);  // 남

        // 각 리스트의 범위를 설정
        for (int i = 0; i < circlePoints.Length; i++)
        {
            Vector3 point = circlePoints[i];

            // NE: x > 0, z > 0
            if (point.x > 0 && point.z > 0)
            {
                if (Vector3.Distance(point, east) < 0.1f) DirectionPoint[Direction.NE].Add(east);
                DirectionPoint[Direction.NE].Add(point);
            }
            // NW: x < 0, z > 0
            else if (point.x < 0 && point.z > 0)
            {
                if (Vector3.Distance(point, north) < 0.1f) DirectionPoint[Direction.NW].Add(north);
                DirectionPoint[Direction.NW].Add(point);
            }
            // SW: x < 0, z < 0
            else if (point.x < 0 && point.z < 0)
            {
                if (Vector3.Distance(point, west) < 0.1f) DirectionPoint[Direction.SW].Add(west);
                DirectionPoint[Direction.SW].Add(point);
            }
            // SE: x > 0, z < 0
            else if (point.x > 0 && point.z < 0)
            {
                if (Vector3.Distance(point, south) < 0.1f) DirectionPoint[Direction.SE].Add(south);
                DirectionPoint[Direction.SE].Add(point);
            }
        }
    }

    IEnumerator MoveObject(Direction direction, GameObject obj)
    {
        if (!DirectionPoint.ContainsKey(direction)) yield break;

        obj.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        // 해당 방향의 리스트만 사용
        List<Vector3> points = DirectionPoint[direction];

        // 첫 번째 점까지 이동 (1초)
        Vector3 startPoint = origin;
        Vector3 firstPoint = points[0];
        yield return MoveOverTime(obj, startPoint, firstPoint, 1f);

        // 분신 생성
        GameObject clone = Instantiate(clonePrefab, firstPoint, Quaternion.identity);
        clones.Add(clone); // 분신 리스트에 추가

        // 나머지 점들을 이동
        float segmentTime = 2f / (points.Count - 1); // 남은 2초를 분배
        for (int i = 0; i < points.Count - 1; i++)
        {
            yield return MoveOverTime(obj, points[i], points[i + 1], segmentTime);

            // 분신 생성
            GameObject newClone = Instantiate(clonePrefab, points[i + 1], Quaternion.identity);
            clones.Add(newClone); // 분신 리스트에 추가
        }

        Destroy(obj, 0.5f); // 원본 오브젝트는 0.5초 후에 삭제
        yield return new WaitForSeconds(0.5f); // 잠시 대기

        // 모든 분신을 1초 내에 목표 지점으로 이동
        Vector3 finalDestination = new Vector3(0, finalDestinationHeight, radius);
        foreach (var _clone in clones)
        {
            StartCoroutine(MoveOverTime(_clone, _clone.transform.position, finalDestination, 1f));
        }

        shield.StartShield();
        // 이동 후 모든 분신 삭제
        yield return new WaitForSeconds(2f);
          foreach (var clone2 in clones)
        {
            Destroy(clone2);
        }
        clones.Clear(); // 리스트 비우기
    }

    IEnumerator MoveOverTime(GameObject obj, Vector3 start, Vector3 end, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            obj.transform.position = Vector3.Lerp(start, end, t);
            yield return null;
        }
        obj.transform.position = end; // 정확히 끝점에 위치
    }
}
