using System.Collections.Generic;
using UnityEngine;

public class FragmentGenerator : MonoBehaviour
{
    public int fragmentCount = 10;       // ���� ����
    public Vector3 cubeSize = Vector3.one; // ������ü ũ��

    private List<Fragment> fragments = new List<Fragment>();

    void Start()
    {
        GenerateFragments();
    }

    void GenerateFragments()
    {
        for (int i = 0; i < fragmentCount; i++)
        {
            // ���� ��ġ�� ũ�� ����
            Vector3 randomPosition = new Vector3(
                Random.Range(-cubeSize.x / 2, cubeSize.x / 2),
                Random.Range(-cubeSize.y / 2, cubeSize.y / 2),
                Random.Range(-cubeSize.z / 2, cubeSize.z / 2)
            );

            Vector3 randomSize = new Vector3(
                Random.Range(0.1f, cubeSize.x / fragmentCount),
                Random.Range(0.1f, cubeSize.y / fragmentCount),
                Random.Range(0.1f, cubeSize.z / fragmentCount)
            );

            // Fragment ����
            Fragment fragment = new Fragment(randomPosition, randomSize);
            fragments.Add(fragment);

            // GameObject�� ����
            CreateFragmentObject(fragment);
        }
    }

    void CreateFragmentObject(Fragment fragment)
    {
        GameObject fragmentObject = new GameObject("Fragment");
        fragmentObject.transform.position = transform.position + fragment.position;

        // MeshRenderer�� MeshFilter �߰�
        MeshRenderer renderer = fragmentObject.AddComponent<MeshRenderer>();
        MeshFilter filter = fragmentObject.AddComponent<MeshFilter>();
        filter.mesh = fragment.mesh;

        // ���� ����
        renderer.material = new Material(Shader.Find("Standard"));
        renderer.material.color = new Color(Random.value, Random.value, Random.value);

        // Rigidbody �߰�
        Rigidbody rb = fragmentObject.AddComponent<Rigidbody>();
        rb.mass = fragment.size.magnitude;
    }
}
