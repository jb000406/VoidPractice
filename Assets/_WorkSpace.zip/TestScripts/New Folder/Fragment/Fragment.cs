using UnityEngine;

public class Fragment
{
    public Vector3 position;      // ������ �߽� ��ġ
    public Vector3 size;          // ������ ũ��
    public Mesh mesh;             // ������ �޽�

    // ������
    public Fragment(Vector3 position, Vector3 size)
    {
        this.position = position;
        this.size = size;
        this.mesh = CreateFragmentMesh(size);
    }

    // �޽� ����
    private Mesh CreateFragmentMesh(Vector3 size)
    {
        Mesh mesh = new Mesh();
        Vector3[] vertices = {
            new Vector3(-size.x, -size.y, -size.z), // 0
            new Vector3( size.x, -size.y, -size.z), // 1
            new Vector3( size.x,  size.y, -size.z), // 2
            new Vector3(-size.x,  size.y, -size.z), // 3
            new Vector3(-size.x, -size.y,  size.z), // 4
            new Vector3( size.x, -size.y,  size.z), // 5
            new Vector3( size.x,  size.y,  size.z), // 6
            new Vector3(-size.x,  size.y,  size.z)  // 7
        };

        int[] triangles = {
            0, 2, 1, 0, 3, 2, // Front
            4, 5, 6, 4, 6, 7, // Back
            0, 1, 5, 0, 5, 4, // Bottom
            2, 3, 7, 2, 7, 6, // Top
            0, 4, 7, 0, 7, 3, // Left
            1, 2, 6, 1, 6, 5  // Right
        };

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();

        return mesh;
    }
}
