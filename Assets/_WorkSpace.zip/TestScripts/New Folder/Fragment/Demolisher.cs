using System.Collections.Generic;
using UnityEngine;

public class Demolisher : MonoBehaviour
{
    public int fragmentCount = 10; // ���� ��

    [SerializeField] private MeshFilter originalMeshFilter;
    [SerializeField] private Mesh originalMesh;
    private List<Fragment> fragments = new List<Fragment>();

    void Start()
    {
        originalMesh = originalMeshFilter.mesh;
        // ����ȭ ����
        Demolish();
    }

    void Demolish()
    {
        // ���� �߽� ����
        Vector3[] fragmentCenters = GenerateFragmentCenters(fragmentCount);

        // �� ���� �޽� ����
        foreach (var center in fragmentCenters)
        {
            Mesh fragmentMesh = GenerateFragmentMesh(originalMesh, center);
            CreateFragmentObject(fragmentMesh, center);
        }
    }

    Vector3[] GenerateFragmentCenters(int count)
    {
        Vector3[] centers = new Vector3[count];
        Bounds bounds = originalMesh.bounds;

        for (int i = 0; i < count; i++)
        {
            centers[i] = new Vector3(
                Random.Range(bounds.min.x, bounds.max.x),
                Random.Range(bounds.min.y, bounds.max.y),
                Random.Range(bounds.min.z, bounds.max.z)
            );
        }

        return centers;
    }

    Mesh GenerateFragmentMesh(Mesh original, Vector3 center)
    {
        Mesh fragmentMesh = new Mesh();

        // ������ �ﰢ�� �����͸� ����ȭ
        Vector3[] vertices = original.vertices;
        int[] triangles = original.triangles;

        List<Vector3> fragmentVertices = new List<Vector3>();
        List<int> fragmentTriangles = new List<int>();

        for (int i = 0; i < triangles.Length; i += 3)
        {
            Vector3 v1 = vertices[triangles[i]];
            Vector3 v2 = vertices[triangles[i + 1]];
            Vector3 v3 = vertices[triangles[i + 2]];

            // ���� �߽ɰ� ����� �ﰢ���� �߰�
            if (Vector3.Distance(v1, center) < 0.5f &&
                Vector3.Distance(v2, center) < 0.5f &&
                Vector3.Distance(v3, center) < 0.5f)
            {
                int baseIndex = fragmentVertices.Count;

                fragmentVertices.Add(v1);
                fragmentVertices.Add(v2);
                fragmentVertices.Add(v3);

                fragmentTriangles.Add(baseIndex);
                fragmentTriangles.Add(baseIndex + 1);
                fragmentTriangles.Add(baseIndex + 2);
            }
        }

        fragmentMesh.vertices = fragmentVertices.ToArray();
        fragmentMesh.triangles = fragmentTriangles.ToArray();
        fragmentMesh.RecalculateNormals();

        return fragmentMesh;
    }

    void CreateFragmentObject(Mesh mesh, Vector3 position)
    {
        GameObject fragment = new GameObject("Fragment");
        fragment.transform.position = transform.position + position;

        MeshFilter filter = fragment.AddComponent<MeshFilter>();
        filter.mesh = mesh;

        MeshRenderer renderer = fragment.AddComponent<MeshRenderer>();
        renderer.material = GetComponent<MeshRenderer>().material;

        Rigidbody rb = fragment.AddComponent<Rigidbody>();
        rb.mass = mesh.bounds.size.magnitude;
    }
}
