using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

public class ThreeDDemolisher : MonoBehaviour
{
    [Header("조각화 설정")]
    [SerializeField] private int maxFragments = 100; // 최대 조각 개수
    [SerializeField] private float explosionForce = 0f; // 폭발 힘
    [SerializeField] private float explosionRadius = 2f; // 폭발 반경
    [SerializeField] private float fragmentLifetime = 20f; // 조각 생존 시간

    [Header("효과 설정")]
    [SerializeField] private ParticleSystem explosionEffect; // 폭발 파티클
    [SerializeField] private AudioClip explosionSound;
    [SerializeField] private AudioSource audioSource;

    [SerializeField] private DrawCircleEffect drawCircleEffect;

    private Bounds meshBounds; // 오브젝트의 경계 상자
    [SerializeField] private Material originalMaterial; // 원본 머티리얼

    private void Start()
    {
        // 원본 머티리얼 저장
        // originalMaterial = GetComponent<MeshRenderer>().material;

        // 경계 상자 초기화
        meshBounds = GetComponent<MeshRenderer>().bounds;
        // 폭발 효과 실행
        Demolish();
    }

    public void Demolish()
    {
        // 폭발 효과 실행
        PlayExplosionEffects();
        // 조각화 시작
        for (int i = 0; i < maxFragments; i++)
        {
            Create3DFragment();
        }

        CallEffect();
        // 원본 오브젝트 제거
        Destroy(gameObject);
     }

    private void CallEffect()
    {
        drawCircleEffect.StartEffect();
    }

    private void Create3DFragment()
    {
        // 랜덤 위치 및 크기 계산
        Vector3 randomPosition = meshBounds.center + new Vector3(
            Random.Range(-meshBounds.extents.x, meshBounds.extents.x),
            Random.Range(-meshBounds.extents.y, meshBounds.extents.y),
            Random.Range(-meshBounds.extents.z, meshBounds.extents.z)
        );

        Vector3 randomScale = new Vector3(
            Random.Range(0.01f, 0.1f) * meshBounds.size.x,
            Random.Range(0.01f, 0.1f) * meshBounds.size.y,
            Random.Range(0.01f, 0.1f) * meshBounds.size.z
        );

        // 조각 생성
        GameObject fragment = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fragment.transform.position = randomPosition;
        fragment.transform.localScale = randomScale;
        fragment.GetComponent<MeshRenderer>().material = originalMaterial;
        SphereCollider sphereCollider = fragment.GetComponent<SphereCollider>();

        // 물리적 요소 추가
        Rigidbody rb = fragment.AddComponent<Rigidbody>();

        // 물리 설정
        rb.useGravity = true;
        rb.mass = 1f;               // 적절한 질량
        rb.linearDamping = 0.5f;               // 낮은 선형 저항
        rb.angularDamping = 0.5f;       // 낮은 회전 저항
        rb.centerOfMass = new Vector3(0, -0.5f, 0); // 무게 중심 아래로 이동

        // 폭발력 적용
        rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);

        //// 초기 회전력 추가
        //Vector3 randomTorque = new Vector3(
        //    Random.Range(-1f, 1f),
        //    Random.Range(-1f, 1f),
        //    Random.Range(-1f, 1f)
        //).normalized;
        //rb.AddTorque(randomTorque, ForceMode.Impulse);
        // 조각 제거 타이머
        Destroy(fragment, fragmentLifetime);
    }

    private void PlayExplosionEffects()
    {
        // 폭발 파티클
        if (explosionEffect != null)
        {
            ParticleSystem effect = Instantiate(explosionEffect, transform.position, Quaternion.identity);
            Destroy(effect.gameObject, effect.main.duration);
        }

        // 폭발 사운드
        if (explosionSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(explosionSound);
        }
    }
}
