using UnityEngine;
using System.Collections;

public class DissolveEffectController : MonoBehaviour
{
    public Material dissolveMaterial; // 디졸브 머티리얼
    public float dissolveSpeed = 1f; // 디졸브 속도
    private float dissolveAmount = 1f; // 디졸브 초기값

    public float fresnelPower = 2f;
    public Color fresnelColor = Color.cyan;
    public float scrollSpeed = 0.1f;

    void Update()
    {
        // Fresnel 및 UV 스크롤 동적 제어
        dissolveMaterial.SetFloat("_FresnelPower", fresnelPower);
        dissolveMaterial.SetColor("_FresnelColor", fresnelColor);
        dissolveMaterial.SetFloat("_ScrollSpeed", scrollSpeed);
    }

    void Start()
    {
        dissolveAmount = 1f;
        dissolveMaterial.SetFloat("_DissolveAmount", dissolveAmount);
        StartCoroutine(DissolveIn());
    }

    IEnumerator DissolveIn()
    {
        while (dissolveAmount > 0f)
        {
            dissolveAmount -= Time.deltaTime * dissolveSpeed;
            dissolveMaterial.SetFloat("_DissolveAmount", dissolveAmount);
            yield return null;
        }
    }
}
