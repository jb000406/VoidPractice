using UnityEngine;
//using UnityEngine.XR.Interaction.Toolkit;

public class XRBarrierInteraction : MonoBehaviour
{
    //public void OnSelectEnter(XRBaseInteractor interactor)
    //{
    //    Debug.Log("XR 컨트롤러가 결계와 상호작용 중...");
    //    // 결계 해제 로직 실행
    //}
}
