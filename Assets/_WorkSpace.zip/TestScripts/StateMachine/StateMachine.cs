using UnityEngine;

public class StateExitBehaviour : StateMachineBehaviour
{
    [SerializeField] private string boolParameterName; // 설정할 Animator Bool 파라미터 이름

    // 스테이트가 종료될 때 호출되는 메서드
    public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (!string.IsNullOrEmpty(boolParameterName))
        {
            animator.SetBool(boolParameterName, false); // Bool 값을 false로 설정
        }
    }
}
