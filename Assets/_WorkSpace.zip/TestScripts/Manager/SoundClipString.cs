public enum SoundClipString
{
    MonsterSound1, MonsterSound2, MonsterSound3, MonsterSound4, MonsterSound5, MonsterSound6, MonsterSound7,
    MonsterSound8, MonsterSound9
}
